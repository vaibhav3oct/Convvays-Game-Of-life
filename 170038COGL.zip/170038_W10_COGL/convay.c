//Author - Vaibhav Kumar Mishra
#include <stdio.h>

int main()
    {

	    printf("Convey's Game of life");
	    printf("\n-------------------------");
	    printf("\nInstructions");
	    printf("\n1 represent Alive State");
	    printf("\n0 represent Dead State");
	    printf("\n-------------------------");
	   	printf("\nRules");
	   	printf("\n1. Any alive cell with less than 2 neighbour dies");
	   	printf("\n2. Any alive call with more than 3 neighbour dies");
	   	printf("\n3. Any dead cell with exactly 3 neighbour become alive");
	    printf("\n-------------------------");
	    printf("\nGrid Size = 10 x 10\n\n");
	    printf("\nInitial State\n\n");
			int grid[10][10] = {
            { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 1, 0, 1, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0 },
			{ 0, 1, 0, 0, 0, 0, 1, 1, 0, 0 },
			{ 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 1, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 1, 0, 0, 0, 0, 0 },
			{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
		};


		for (int r = 0; r < 10; r++)
        {
            for (int c = 0; c < 10; c++)
            {
                if (grid[r][c] == 0)
                    printf("0 ");
                else
                    printf("1 ");
            }
           printf("\n");
        }
       printf("\n");

        rulesimplimentation(grid, 10, 10);
    }


    void rulesimplimentation(int grid[10][10])
    {

        for (int r = 1; r < 10 - 1; r++)
        {
            for (int c = 1; c < 10 - 1; c++)
            {

                int aliveNeighbours = 0;

                for (int i = -1; i <= 1; i++)

                    for (int j = -1; j <= 1; j++)

                        aliveNeighbours += grid[r + i][c + j];

                aliveNeighbours -= grid[r][c];


                if ((grid[r][c] == 1) && (aliveNeighbours < 2))
                	grid[r][c]=0;
                else if ((grid[r][c] == 1) && (aliveNeighbours > 3))
                                    grid[r][c] = 0;
                else if ((grid[r][c] == 0) && (aliveNeighbours == 3))
                                    grid[r][c] = 1;


            }
        }

        printf("\nNext Generation\n\n");

        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (grid[i][j] == 0)
                   printf("0 ");
                else
                    printf("1 ");
            }
            printf("\n");
        }
        printf("\n");
    }
